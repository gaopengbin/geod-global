GeoD independent QA controls; no third-party geographic data.
